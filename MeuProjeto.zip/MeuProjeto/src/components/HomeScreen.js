import React from 'react';
import casual_dog from '../assets/casual_dog.png';
import { TouchableOpacity, View, Text, StyleSheet, Dimensions, Image } from 'react-native';

const windowWidth = Dimensions.get('window').width;

export default function HomeScreen({ navigation }) {


    return (
        
        <View style={styles.container}>
            <Image
            source={casual_dog}
        />
            <Text style={styles.title}>Ótimo dia!</Text>
            <View style={styles.buttonContainer}>

            </View>
            <View style={styles.buttonContainer}>
 
            </View>

        </View>
    );
}

const styles = StyleSheet.create({

});